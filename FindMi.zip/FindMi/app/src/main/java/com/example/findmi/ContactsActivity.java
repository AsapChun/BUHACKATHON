package com.example.findmi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ContactsActivity extends AppCompatActivity {

    private EditText edtContact1;
    private EditText edtContact2;
    private EditText edtContact3;
    private EditText edtName;
    private EditText edtContact5;

    private Button btnSaveContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
        edtName = (EditText) findViewById(R.id.edtName);
        edtContact1 = (EditText) findViewById(R.id.edtContact1);
        edtContact2 = (EditText) findViewById(R.id.edtContact2);
        edtContact3 = (EditText) findViewById(R.id.edtContact3);


        btnSaveContact = (Button) findViewById(R.id.btnSaveContact);

        btnSaveContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSharedPreferenceInfo();
                goBack();
            }
        });

    }

    void saveSharedPreferenceInfo(){
        //1. Refer to the SharedPreference Object.
        SharedPreferences simpleAppInfo = getSharedPreferences("ContactsActivity", Context.MODE_PRIVATE);  //Private means no other Apps can access this.

        //2. Create an Shared Preferences Editor for Editing Shared Preferences.
        //Note, not a real editor, just an object that allows editing...

        SharedPreferences.Editor editor = simpleAppInfo.edit();

        //3. Store what's important!  Key Value Pair, what else is new...
        editor.putString("name", getLostName(edtName.getText().toString()));
        editor.putString("contact1", phonenumberparse(edtContact1.getText().toString()));
        editor.putString("contact2", phonenumberparse(edtContact2.getText().toString()));
        editor.putString("contact3", phonenumberparse(edtContact3.getText().toString()));


        //4. Save your information.
        editor.apply();

        Toast.makeText(this, "Shared Preference Data Updated.", Toast.LENGTH_LONG).show();
    }

    public static String getLostName(String str) {
        String[] parsed = str.split(":");
        if (parsed.length != 2) return "Someone";
        return parsed[1];
    }

    public static String phonenumberparse(String str) {
        String[] parsed = str.split("#");
        if (parsed.length != 2) return null;
        String info = parsed[1];
        String possible = "0123456789";
        //ArrayList<String> digits = Stream.of("0","1","2","3","4","5","6","7","8","9");

        String[] info_char = info.split("");
        String number = "";
        for (int i = 0; i < info_char.length; i++) {
            if (possible.contains(info_char[i])) //digits.contains(info_char[i]))
                number += info_char[i];
            // System.out.println(number);
        }
        if (number.length() == 11) {
            //System.out.println(number);
            /** int ret = Integer.parseInt(number); */
            return number;
        }
        else if (number.length() == 10) {
            //String usac_number = "1" + number;
            number = "1" + number;
            /** int ret = Integer.parseInt(usac_number); */
            //System.out.println(number);
            return number;
        }
        else return null;
    }






    public void goBack() {
        this.finish();
    }


}
