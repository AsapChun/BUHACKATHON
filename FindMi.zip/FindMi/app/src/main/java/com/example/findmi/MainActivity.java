package com.example.findmi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class MainActivity extends AppCompatActivity {

    private Button btnLost;
    private Location curPos;
    private FusedLocationProviderClient FLPC;
    private double lon;
    private double lat;
    private String name;
    private String contact1;
    private String contact2;
    private String contact3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLost = (Button) findViewById(R.id.btnLost);
        FLPC = LocationServices.getFusedLocationProviderClient(this);

        btnLost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);

                FLPC.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {

                            lon = location.getLongitude();
                            lat = location.getLatitude();

                        }
                    }
                });


               retrieveSharedPreferenceInfo();

                    try {
                        String phoneNo = contact1;
                        String message = name + " is lost! Please help! SOS! Copy and Paste! Location: Current latitude: " + lat + ", current longitude: " + lon;

                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNo, null, message, null, null);
                        Toast.makeText(getApplicationContext(), "SMS sent.", Toast.LENGTH_LONG).show();
                    }
                    catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "SMS failed, please try again.", Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                    try {
                        String phoneNo = contact2;
                        String message = name + " is lost! Please help! SOS! Copy and Paste! Location: Current latitude: " + lat + ", current longitude: " + lon;

                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNo, null, message, null, null);
                        Toast.makeText(getApplicationContext(), "SMS sent.", Toast.LENGTH_LONG).show();
                    }
                    catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "SMS failed, please try again.", Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }


                    try {
                        String phoneNo = contact3;
                        String message = name + " is lost! Please help! SOS! Copy and Paste! Location: Current latitude: " + lat + ", current longitude: " + lon;

                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNo, null, message, null, null);
                        Toast.makeText(getApplicationContext(), "SMS sent.", Toast.LENGTH_LONG).show();
                    }
                    catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "SMS failed, please try again.", Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }



              }

        });
    }


    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.itmContacts:
                Toast.makeText(getApplicationContext(), "Profile Selected", Toast.LENGTH_SHORT).show();
                goToContacts();

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void goToContacts(){
        Intent newIntent = new Intent(this, ContactsActivity.class);
        this.startActivity(newIntent);
    }

    void retrieveSharedPreferenceInfo(){
        SharedPreferences simpleAppInfo = getSharedPreferences("ContactsActivity", Context.MODE_PRIVATE);

        name = simpleAppInfo.getString("name", "<missing>");
        contact1 = simpleAppInfo.getString("contact1", "<missing>");
        contact2 = simpleAppInfo.getString("contact2", "<missing>");
        contact3 = simpleAppInfo.getString("contact3", "<missing>");

    }
}
